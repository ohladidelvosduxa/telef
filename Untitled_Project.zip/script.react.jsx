import React, { useState } from 'react';

function App() {
  // Состояние для отслеживания текущего экрана
  const [currentScreen, setCurrentScreen] = useState('main');
  
  // 15 разных фонов для экранов
  const backgrounds = {
    main: '#FF0000', // Красный (главный экран)
    screen1: '#FFFFFF', // Белый
    screen2: '#87CEEB', // Голубой
    screen3: '#90EE90', // Зеленый
    screen4: '#FFFFE0', // Желтый
    screen5: '#D8BFD8', // Фиолетовый
    screen6: '#FFDAB9', // Персиковый
    screen7: '#B0E0E6', // Пудровый
    screen8: '#F0FFF0', // Медовый
    screen9: '#F0F8FF', // Небесный
    screen10: '#000000', // Черный (10-й экран - черно-желтый)
    screen11: '#FFFFFF', // Белый
    screen12: '#87CEEB', // Голубой
    screen13: '#90EE90', // Зеленый
    screen14: '#000000', // Черный (14-й экран - черно-желтый)
    screen15: '#FFFFFF', // Белый
  };
  
  // Добавляем желтый для 10-го и 14-го экранов
  if (currentScreen === 'screen10' || currentScreen === 'screen14') {
    backgrounds[currentScreen] = 'linear-gradient(45deg, #000000 50%, #FFFF00 50%)'; // Черно-желтый градиент
  }
  
  // 15 разных надписей
  const screens = [
    "Главная", "Новости", "Сообщения", 
    "Звонки", "Контакты", "Настройки", 
    "Галерея", "Музыка", "Видео", 
    "Игры", "Камера", "Календарь", 
    "Погода", "Браузер", "Профиль"
  ];
  
  // Стили контейнера (телефон)
  const phoneStyle = {
    width: '350px',
    height: '600px',
    backgroundColor: '#333',
    borderRadius: '30px',
    padding: '10px',
    position: 'relative',
    boxShadow: '0 0 20px rgba(0, 0, 0, 0.5)',
    margin: '0 auto',
    overflow: 'hidden',
  };
  
  // Стили для экрана телефона
  const screenStyle = {
    width: '100%',
    height: '90%',
    backgroundColor: backgrounds[currentScreen],
    borderRadius: '20px',
    position: 'relative',
    overflow: 'hidden',
    transition: 'background-color 0.5s ease',
  };
  
  // Стили для надписей на главном экране
  const appIconStyle = {
    position: 'absolute',
    width: '60px',
    height: '60px',
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderRadius: '15px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    cursor: 'pointer',
    fontSize: '12px',
    textAlign: 'center',
    transition: 'transform 0.3s ease',
  };
  
  // Позиции для 15 иконок на главном экране
  const positions = [
    { top: '10%', left: '10%' },
    { top: '10%', left: '40%' },
    { top: '10%', right: '10%' },
    { top: '30%', left: '10%' },
    { top: '30%', left: '40%' },
    { top: '30%', right: '10%' },
    { top: '50%', left: '10%' },
    { top: '50%', left: '40%' },
    { top: '50%', right: '10%' },
    { top: '70%', left: '10%' },
    { top: '70%', left: '40%' },
    { top: '70%', right: '10%' },
    { top: '90%', left: '10%' },
    { top: '90%', left: '40%' },
    { top: '90%', right: '10%' },
  ];
  
  // Стили для кнопки "Назад"
  const backButtonStyle = {
    position: 'absolute',
    top: '10px',
    left: '10px',
    padding: '8px 15px',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
    cursor: 'pointer',
    zIndex: 10,
  };
  
  return (
    <div style={{ padding: '20px' }}>
      <div style={phoneStyle}>
        <div style={screenStyle}>
          {/* Кнопка "Назад" (показывается не на главном экране) */}
          {currentScreen !== 'main' && (
            <button 
              style={backButtonStyle}
              onClick={() => setCurrentScreen('main')}
            >
              Назад
            </button>
          )}
          
          {/* Отображаем иконки только на главном экране */}
          {currentScreen === 'main' && screens.map((text, index) => (
            <div
              key={index}
              style={{
                ...appIconStyle,
                top: positions[index].top,
                left: positions[index].left,
                right: positions[index].right,
              }}
              onClick={() => setCurrentScreen(`screen${index + 1}`)}
              onMouseOver={(e) => e.target.style.transform = 'scale(1.1)'}
              onMouseOut={(e) => e.target.style.transform = 'scale(1)'}
            >
              {text}
            </div>
          ))}
          
          {/* Содержимое для других экранов */}
          {currentScreen !== 'main' && (
            <div style={{ 
              display: 'flex', 
              justifyContent: 'center', 
              alignItems: 'center', 
              height: '100%', 
              color: currentScreen === 'screen10' || currentScreen === 'screen14' ? 'white' : 'black',
              fontSize: '24px',
              textAlign: 'center',
              padding: '20px'
            }}>
              <h2>{screens[parseInt(currentScreen.replace('screen', '')) - 1]}</h2>
            </div>
          )}
        </div>
        
        {/* Кнопки телефона (имитация) */}
        <div style={{ 
          position: 'absolute', 
          bottom: '10px', 
          left: '50%', 
          transform: 'translateX(-50%)',
          width: '60px',
          height: '5px',
          backgroundColor: '#666',
          borderRadius: '3px'
        }}></div>
      </div>
    </div>
  );
}

export default App;